document.addEventListener('DOMContentLoaded', function(){
  const search = document.getElementById('classSearch');
  const grid = document.getElementById('gradesGrid');
  if (!search || !grid) return;

  search.addEventListener('input', function(e){
    const q = e.target.value.trim().toLowerCase();
    const cards = grid.querySelectorAll('.grade-card');
    cards.forEach(card => {
      const title = card.getAttribute('data-title') || '';
      if (!q || title.toLowerCase().includes(q)){
        card.style.display = '';
      } else {
        card.style.display = 'none';
      }
    });
  });

  // Simple keyboard shortcut: press '/' to focus search
  document.addEventListener('keydown', function(e){
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA'){
      e.preventDefault();
      search.focus();
    }
  });
});

// Enable Bootstrap tooltips and helper interactions across unit pages
document.addEventListener('DOMContentLoaded', function(){
  // Bootstrap tooltip init (if bootstrap is loaded)
  try {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.forEach(function (el) {
      // eslint-disable-next-line no-undef
      new bootstrap.Tooltip(el);
    });
  } catch (err) {
    // bootstrap not present or already initialized
  }

  // Copy-to-clipboard for any .btn-copy inside a unit
  document.querySelectorAll('.btn-copy').forEach(function(btn){
    btn.addEventListener('click', function(){
      var target = document.querySelector(btn.getAttribute('data-copy-target'));
      if (!target) return;
      var text = target.innerText || target.textContent || '';
      navigator.clipboard?.writeText(text).then(function(){
        var old = btn.innerHTML;
        btn.innerHTML = 'Copied ✓';
        setTimeout(function(){ btn.innerHTML = old; }, 1500);
      }).catch(function(){
        // fallback: select and prompt
        var range = document.createRange();
        range.selectNodeContents(target);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        try { document.execCommand('copy'); btn.innerHTML = 'Copied ✓'; } catch(e) { alert('Copy failed.'); }
        sel.removeAllRanges();
        setTimeout(function(){ btn.innerHTML = 'Copy Notes'; }, 1500);
      });
    });
  });
});
