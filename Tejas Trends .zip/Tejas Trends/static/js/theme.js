(function(){
  const storageKey = 'tj_theme';
  const toggle = () => {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    if(isDark){
      document.documentElement.removeAttribute('data-theme');
      localStorage.setItem(storageKey,'light');
      setIcon(false);
    } else {
      document.documentElement.setAttribute('data-theme','dark');
      localStorage.setItem(storageKey,'dark');
      setIcon(true);
    }
  };
  const setIcon = (dark)=>{
    const icon = document.getElementById('theme-icon');
    if(!icon) return;
    icon.className = dark ? 'fa-solid fa-sun' : 'fa-regular fa-moon';
  };
  document.addEventListener('DOMContentLoaded', function(){
    try{
      const saved = localStorage.getItem(storageKey);
      if(saved === 'dark'){
        document.documentElement.setAttribute('data-theme','dark');
        setIcon(true);
      } else {
        document.documentElement.removeAttribute('data-theme');
        setIcon(false);
      }
      const btn = document.getElementById('theme-toggle');
      if(btn) btn.addEventListener('click', toggle);
    }catch(e){console.warn('theme init',e)}
  });
})();
