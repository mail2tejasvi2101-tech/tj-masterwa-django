from django.contrib import admin
from .models import Student, StudentActivity, Quiz, QuizResult


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'class_number', 'school_name', 'last_login', 'is_active')
    search_fields = ('name', 'email', 'school_name')
    list_filter = ('class_number', 'is_active')


@admin.register(StudentActivity)
class StudentActivityAdmin(admin.ModelAdmin):
    list_display = ('student', 'page_visited', 'exercise_completed', 'timestamp')
    search_fields = ('student__name', 'page_visited')
    list_filter = ('exercise_completed',)


@admin.register(Quiz)
class QuizAdmin(admin.ModelAdmin):
    list_display = ('class_number', 'part', 'chapter', 'quiz_number', 'total_questions')
    search_fields = ('chapter',)
    list_filter = ('class_number', 'part', 'quiz_number')


@admin.register(QuizResult)
class QuizResultAdmin(admin.ModelAdmin):
    list_display = ('student', 'quiz', 'marks_obtained', 'percentage', 'completed_at')
    search_fields = ('student__name', 'quiz__chapter')
    list_filter = ('quiz__class_number', 'quiz__part')
