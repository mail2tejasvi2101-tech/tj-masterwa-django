from django.db import models
from django.contrib.auth.hashers import make_password, check_password

class Student(models.Model):
    """Student model for tracking attentiveness and engagement."""
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    class_number = models.IntegerField(choices=[(i, f'Class {i}') for i in range(3, 11)])
    school_name = models.CharField(max_length=255)
    password_hash = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    last_login = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    
    # Tracking fields
    pages_visited = models.IntegerField(default=0)
    exercises_completed = models.IntegerField(default=0)
    units_completed = models.IntegerField(default=0)
    
    class Meta:
        ordering = ['-last_login']
    
    def set_password(self, password):
        """Hash and set password."""
        self.password_hash = make_password(password)
    
    def check_password(self, password):
        """Check if provided password matches hashed password."""
        return check_password(password, self.password_hash)
    
    def __str__(self):
        return f"{self.name} (Class {self.class_number})"


class StudentActivity(models.Model):
    """Track student activity for admin insights."""
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='activities')
    page_visited = models.CharField(max_length=500)
    exercise_completed = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"{self.student.name} - {self.page_visited}"


class Quiz(models.Model):
    """Quiz model for storing quiz information."""
    CHAPTERS = (
        # Class 10 Part A (Skills)
        ('leadership-skills', 'Leadership Skills'),
        ('self-management-skills', 'Self-Management Skills II'),
        ('ict-skills', 'ICT Skills II'),
        ('entrepreneurial-skills', 'Entrepreneurial Skills II'),
        ('green-skills', 'Green Skills II'),
        # Class 10 Part B (IT/Digital Skills)
        ('communication', 'Communication Skills'),
        ('digital-documentation', 'Digital Documentation'),
        ('electronic-spreadsheet', 'Electronic Spreadsheet'),
        ('database-management', 'Database Management'),
        ('web-apps-security', 'Web Apps & Security'),
    )
    
    class_number = models.IntegerField(choices=[(i, f'Class {i}') for i in range(3, 11)])
    part = models.CharField(max_length=10, choices=[('part-a', 'Part A'), ('part-b', 'Part B')])
    chapter = models.CharField(max_length=100)  # Changed from choice field to allow flexible chapter names
    quiz_number = models.IntegerField(default=1)  # Quiz-1, Quiz-2, etc.
    total_questions = models.IntegerField(default=10)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('class_number', 'part', 'chapter', 'quiz_number')
        ordering = ['class_number', 'part', 'chapter', 'quiz_number']
    
    def __str__(self):
        return f"Class {self.class_number} - {self.part.upper()} - {self.chapter} - Quiz {self.quiz_number}"


class QuizResult(models.Model):
    """Store student quiz results and marks."""
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='quiz_results')
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name='results')
    marks_obtained = models.IntegerField(default=0)  # Out of total_questions
    percentage = models.FloatField(default=0.0)
    completed_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('student', 'quiz')
        ordering = ['-completed_at']
    
    def save(self, *args, **kwargs):
        """Calculate percentage before saving."""
        if self.quiz:
            self.percentage = (self.marks_obtained / self.quiz.total_questions) * 100
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.student.name} - {self.quiz} - {self.marks_obtained}/{self.quiz.total_questions}"
