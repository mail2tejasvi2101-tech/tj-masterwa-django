from django.urls import path
from . import views

app_name = 'website'

urlpatterns = [
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('signup/', views.student_signup, name='student_signup'),
    path('login/', views.student_login, name='student_login'),
    path('logout/', views.student_logout, name='student_logout'),
    path('api/submit-quiz/', views.submit_quiz, name='submit_quiz'),
    path('classes/<int:grade>/', views.class_detail, name='class_detail'),
    # Slug-based unit pages (e.g. part-b/digital-documentation/)
    path('classes/<int:grade>/<str:part>/<str:slug>/', views.unit_slug_detail, name='unit_slug_detail'),
    # Numeric unit pages (e.g. part-a/unit-3/)
    path('classes/<int:grade>/<str:part>/unit-<int:unit>/', views.unit_detail, name='unit_detail'),
]
