from django.shortcuts import render, redirect
from django.template import TemplateDoesNotExist
from django.template.loader import get_template
from django.contrib import messages
from django.utils import timezone
from django.db.models import Avg
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from .models import Student, StudentActivity, Quiz, QuizResult
from .forms import StudentSignupForm, StudentLoginForm


def login_required_view(view_func):
    """Decorator to require student login."""
    def wrapper(request, *args, **kwargs):
        if 'student_id' not in request.session:
            messages.warning(request, 'Please login to access this page.')
            return redirect('website:student_login')
        return view_func(request, *args, **kwargs)
    return wrapper


def home(request):
    """Home page - redirect to login if not authenticated."""
    if 'student_id' not in request.session:
        return render(request, 'welcome.html')
    
    try:
        student = Student.objects.get(id=request.session['student_id'])
    except Student.DoesNotExist:
        return render(request, 'welcome.html')
    
    grades = [3, 4, 5, 6, 7, 8, 9, 10]
    return render(request, 'index.html', {'grades': grades, 'student': student})


def dashboard(request):
    """Student dashboard showing progress and quiz marks."""
    if 'student_id' not in request.session:
        messages.warning(request, 'Please login to access your dashboard.')
        return redirect('website:student_login')
    
    try:
        student = Student.objects.get(id=request.session['student_id'])
    except Student.DoesNotExist:
        messages.error(request, 'Student not found.')
        return redirect('website:student_login')
    
    # Get all quiz results for this student
    quiz_results = QuizResult.objects.filter(student=student).select_related('quiz')
    
    # Calculate average marks across all quizzes
    avg_percentage = quiz_results.aggregate(Avg('percentage'))['percentage__avg'] or 0
    
    # Group results by chapter for better display
    results_by_chapter = {}
    for result in quiz_results:
        chapter_name = result.quiz.chapter
        if chapter_name not in results_by_chapter:
            results_by_chapter[chapter_name] = []
        results_by_chapter[chapter_name].append(result)
    
    # Calculate progress level (0-100)
    total_quizzes = quiz_results.count()
    progress_level = avg_percentage if total_quizzes > 0 else 0
    
    context = {
        'student': student,
        'quiz_results': quiz_results,
        'results_by_chapter': results_by_chapter,
        'total_quizzes': total_quizzes,
        'avg_percentage': round(avg_percentage, 2),
        'progress_level': round(progress_level, 2),
    }
    
    return render(request, 'dashboard.html', context)


def submit_quiz(request):
    """Handle quiz submission via AJAX."""
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    
    if 'student_id' not in request.session:
        return JsonResponse({'error': 'Not authenticated'}, status=401)
    
    import json
    try:
        data = json.loads(request.body)
    except:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    
    # Support both old and new formats
    class_number = data.get('class_number') or data.get('class')
    part = data.get('part') or 'part-a'  # Default to part-a for new units
    chapter = data.get('chapter')
    quiz_name = data.get('quiz_name', 'Quiz-1')
    
    # Extract quiz number from quiz_name (e.g., "Quiz-1" -> 1)
    quiz_number = int(quiz_name.split('-')[-1]) if '-' in quiz_name else 1
    
    # Support both 'score'/'marks' and calculate marks from percentage if needed
    marks = data.get('marks') or data.get('score')
    total_questions = data.get('total_questions') or data.get('total', 10)
    
    try:
        student = Student.objects.get(id=request.session['student_id'])
    except Student.DoesNotExist:
        return JsonResponse({'error': 'Student not found'}, status=404)
    
    try:
        # Create or get the quiz
        quiz, created = Quiz.objects.get_or_create(
            class_number=int(class_number),
            part=part,
            chapter=chapter,
            quiz_number=quiz_number,
            defaults={'total_questions': int(total_questions)}
        )
        
        # Create or update quiz result
        quiz_result, created = QuizResult.objects.update_or_create(
            student=student,
            quiz=quiz,
            defaults={'marks_obtained': int(marks)}
        )
        
        return JsonResponse({
            'success': True,
            'quiz_id': quiz.id,
            'marks': quiz_result.marks_obtained,
            'total': quiz.total_questions,
            'percentage': round(quiz_result.percentage, 1),
            'message': 'Quiz results saved successfully!'
        })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


def class_detail(request, grade):
    """Class detail page - requires login. All classes unlocked."""
    if 'student_id' not in request.session:
        messages.warning(request, 'Please login to access classes.')
        return redirect('website:student_login')
    
    try:
        student = Student.objects.get(id=request.session['student_id'])
    except Student.DoesNotExist:
        messages.error(request, 'Student not found.')
        return redirect('website:student_login')
    
    try:
        g = int(grade)
    except (TypeError, ValueError):
        g = grade
    
    # First try a class-specific static template like `class_9.html` or `class_10.html`.
    template_name = f'class_{g}.html'
    try:
        get_template(template_name)
        return render(request, template_name, {'grade': g, 'student': student, 'is_locked': False})
    except TemplateDoesNotExist:
        pass

    return render(request, 'class_detail.html', {'grade': g, 'student': student, 'is_locked': False})


def unit_detail(request, grade, part, unit):
    """Generic unit detail view - requires login and enforces class restrictions."""
    if 'student_id' not in request.session:
        messages.warning(request, 'Please login to access units.')
        return redirect('website:student_login')
    
    try:
        student = Student.objects.get(id=request.session['student_id'])
    except Student.DoesNotExist:
        messages.error(request, 'Student not found.')
        return redirect('website:student_login')
    
    try:
        g = int(grade)
    except (TypeError, ValueError):
        g = grade

    context = {
        'grade': g,
        'part': part,
        'unit': unit,
        'title': f'Class {g} — {part} — Unit {unit}',
        'content_html': '',
        'student': student,
        'is_locked': False,
    }

    # Try to load a unit-specific template first
    template_path = f'units/class{g}/{part}/unit-{unit}.html'
    try:
        get_template(template_path)
        return render(request, template_path, context)
    except TemplateDoesNotExist:
        pass

    # Embedded content for Class 10 Part A Unit 1
    if g == 10 and part.lower() in ('part-a', 'part_a') and int(unit) == 1:
        context['title'] = 'Communication Skills – II'
        context['content_html'] = '''
<h3>To kya hai aap sabke – Communication Skills ka full detail!</h3>
<h4>1. Communication Skills kya hote hain?</h4>
<p>Communication ka matlab hai baat ko samajhna aur samjhaana – matlab information ko exchange karna.
Ye sirf bolne tak limited nahi hai, balki sunna, samajhna aur sahi jawab dena bhi communication ka part hai.</p>
<p><strong>Example:</strong> Aap teacher se question poochte ho, teacher answer deti hai – ye communication hai. Agar teacher ne galat samjha, toh communication fail ho gaya.</p>

<h4>2. Communication ke Types</h4>
<p>IT 402 me ye bahut important hai. Chaar main types hote hain:</p>
<ol>
  <li><strong>Verbal Communication</strong><br>Jo hum bol kar karte hain.<br><em>Example:</em> Classroom discussion, phone call.<br><em>Tip:</em> Clear bolo, simple words use karo.</li>
  <li><strong>Non-Verbal Communication</strong><br>Jo hum body language, gestures, facial expressions se karte hain.<br><em>Example:</em> Smile karna = positive signal.<br><em>Tip:</em> Eye contact maintain karo.</li>
  <li><strong>Written Communication</strong><br>Jo hum likh kar karte hain.<br><em>Example:</em> Email, letter, WhatsApp message.<br><em>Tip:</em> Grammar sahi rakho, short and clear likho.</li>
  <li><strong>Visual Communication</strong><br>Jo hum images, charts, diagrams se karte hain.<br><em>Example:</em> PPT presentation, infographics.</li>
</ol>

<h4>3. Communication Process</h4>
<p>Isme 5 main elements hote hain:</p>
<ul>
  <li><strong>Sender</strong> – Jo message bhej raha hai.</li>
  <li><strong>Message</strong> – Jo information hai.</li>
  <li><strong>Medium</strong> – Kaise bhej rahe ho (phone, email, face-to-face).</li>
  <li><strong>Receiver</strong> – Jo message receive kar raha hai.</li>
  <li><strong>Feedback</strong> – Receiver ka response.</li>
</ul>
<p><strong>Example:</strong><br>Aap WhatsApp pe message bhejte ho → Friend read karta hai → Reply karta hai → Feedback complete.</p>

<h4>4. Barriers to Communication</h4>
<p>Ye exam me short question aata hai. Barriers matlab jo communication ko rokta hai:</p>
<ul>
  <li>Language difference</li>
  <li>Noise</li>
  <li>Emotional barriers</li>
  <li>Lack of clarity</li>
  <li>Cultural difference</li>
</ul>

<h4>5. Tips to Improve Communication</h4>
<ul>
  <li>Active Listening – Dhyan se suno.</li>
  <li>Clarity – Simple words use karo.</li>
  <li>Positive Body Language – Smile, eye contact.</li>
  <li>Empathy – Dusre ki feelings samjho.</li>
  <li>Practice – Daily conversation karo.</li>
</ul>
'''

    # Embedded content for Class 10 Part A Unit 2
    elif g == 10 and part.lower() in ('part-a', 'part_a') and int(unit) == 2:
        context['title'] = 'Self‑Management Skills – II'
        context['content_html'] = '''
<h3>To kya hai aap sabke – Self‑Management Skills – II ka full detail!</h3>
<h4>1. Self‑Management Skills kya hote hain?</h4>
<p>Self‑management ka matlab hai apne kaam, time, emotions aur goals ko control karna.
Socho tumhare paas 24 ghante hain, aur tumne pura din Instagram scroll kar diya – ye self-management fail hai!
Agar tumne apna time plan kiya, stress handle kiya, aur apne goals achieve kiye – ye hi self-management hai.</p>

<h4>2. Stress Management Techniques</h4>
<p>Stress hota hai jab workload zyada ho ya pressure ho.<br>
Example: Exam ke ek din pehle 10 chapters pending hain – tension full!</p>
<ul>
    <li><strong>Deep Breathing</strong> – 5 min relax karo, oxygen leke brain ko reboot karo.</li>
    <li><strong>Exercise</strong> – Walk, yoga – body active, mind fresh.</li>
    <li><strong>Positive Thinking</strong> – “Main kar sakta hoon” socho, “Main fail ho jaunga” mat socho.</li>
    <li><strong>Breaks</strong> – Study ke beech short breaks lo, warna brain fry ho jayega.</li>
</ul>

<h4>3. Time Management Skills</h4>
<p>Time ko sahi tarike se use karna.</p>
<p>Example: Tumhare paas 2 ghante hain – tumne 1 ghanta memes pe waste kar diya, bacha 1 ghanta – panic mode ON!</p>
<p><strong>Tips:</strong></p>
<ul>
    <li>To-Do List banao – kya karna hai likho.</li>
    <li>Prioritize Tasks – Important kaam pehle.</li>
    <li>Avoid Distractions – Phone silent, Instagram uninstall (thoda time ke liye).</li>
    <li>Pomodoro Technique – 25 min study + 5 min break – mast technique hai.</li>
</ul>

<h4>4. Goal Setting</h4>
<p>SMART Goals set karo:</p>
<ul>
    <li><strong>S</strong> – Specific</li>
    <li><strong>M</strong> – Measurable</li>
    <li><strong>A</strong> – Achievable</li>
    <li><strong>R</strong> – Relevant</li>
    <li><strong>T</strong> – Time-bound</li>
</ul>
<p>Example:<br>“Main 1 month me 10 chapters complete karunga” – ye SMART goal hai.<br>“Main NASA join karunga kal se” – ye unrealistic hai!</p>

<h4>5. Self-Motivation Tips</h4>
<ul>
    <li>Apne success visualize karo – socho tum topper ho.</li>
    <li>Small rewards do after completing tasks – ek chocolate khud ko gift karo.</li>
    <li>Positive logon ke sath time spend karo – negative log tumhara confidence tod denge.</li>
</ul>

<h4>🎯 11) Interest vs Ability</h4>
<ul>
    <li><strong>Interest ❤️:</strong> Jo pasand hai.</li>
    <li><strong>Ability 💪:</strong> Jo kar sakte ho.</li>
    <li><strong>Ideal Career = Interest + Ability ✅</strong></li>
</ul>
<p><strong>Examples:</strong></p>
<ul>
    <li>Cricket pasand hai (interest) + acha khelte ho (ability) → pursue karo.</li>
    <li>Coding pasand (interest) lekin weak logic (ability low) → practice plan banao.</li>
</ul>

<h4>🪞 12) Self‑Awareness and Its Types</h4>
<p><strong>Self‑awareness =</strong> Apne emotions, strengths, weaknesses samajhna.<br>
<strong>Types:</strong></p>
<ul>
    <li><strong>Internal:</strong> Apne thoughts/feelings.</li>
    <li><strong>External:</strong> Others ka perception.</li>
</ul>

<h4>🧠 13) Self‑Awareness Assessment</h4>
<ul>
    <li><strong>Journaling 📓:</strong> Daily 5 lines—What went well? What to improve?</li>
    <li><strong>Feedback 🔄:</strong> Teachers/friends se specific input.</li>
    <li><strong>Reflections 🪞:</strong> Weekly review: wins, gaps, next steps.</li>
</ul>
<p><strong>Example:</strong> Sunday night: "Is week distraction kis time zyada hua? Next week phone off 8–10 pm." → actionable insight.</p>

<h4>🌱 14) How to Become Self‑Aware (Practical Steps)</h4>
<ul>
    <li><strong>Pause ⏸️:</strong> Reaction se pehle 10‑second rule.</li>
    <li><strong>Name It 🏷️:</strong> "I feel anxious/angry—kyun?"</li>
    <li><strong>Trace Trigger 🧲:</strong> Kis situation se hua?</li>
    <li><strong>Choose Response 🔁:</strong> Breath + plan + speak calmly.</li>
    <li><strong>Track 🗂️:</strong> Journal/notes me patterns.</li>
    <li><strong>Seek Mentors 👩‍🏫:</strong> Guidance for blind spots.</li>
</ul>
<p><strong>Example:</strong> Group study me jab kisi ka loud tone hota, aap irritate hote → next time noise‑free place choose karo.</p>

<h4>🏆 15) Working Independently & SMART Goals</h4>
<p><strong>SMART =</strong></p>
<ul>
    <li><strong>Specific 🎯:</strong> "Maths Algebra—Chapter 4"</li>
    <li><strong>Measurable 📏:</strong> "30 MCQs + 2 numericals/day"</li>
    <li><strong>Achievable ✅:</strong> "Daily 45 minutes"</li>
    <li><strong>Relevant 🔗:</strong> "Board exam target"</li>
    <li><strong>Time‑bound ⏰:</strong> "Complete in 10 days"</li>
</ul>
<p><strong>Bad:</strong> "Improve English."<br>
<strong>Good (SMART):</strong> "Daily 20 new words for 10 days, use in 5 sentences."<br>
<strong>Real‑World Example - Science Project:</strong></p>
<ul>
    <li><strong>S:</strong> "Water purification model"</li>
    <li><strong>M:</strong> "3 methods demo + TDS meter readings"</li>
    <li><strong>A:</strong> "Materials within ₹500"</li>
    <li><strong>R:</strong> "Practical application for school fair"</li>
    <li><strong>T:</strong> "Finish by 25 Jan, rehearse 26 Jan"</li>
</ul>

<h4>⏳ 16) Time Management & Its Importance</h4>
<p><strong>Importance:</strong> Stress kam, output high, deadlines met, free time milta. 🕊️<br>
<strong>Methods:</strong></p>
<ul>
    <li><strong>Prioritize (Eisenhower Box):</strong>
        <ul>
            <li>Urgent+Important → Do now</li>
            <li>Important, Not Urgent → Plan</li>
            <li>Urgent, Not Important → Delegate/limit</li>
            <li>Not Urgent, Not Important → Avoid</li>
        </ul>
    </li>
    <li><strong>Pomodoro 🍅:</strong> 25 min focus + 5 min break (4 cycles = long break)</li>
    <li><strong>Time Blocking ⌚:</strong> Subject‑wise slots (AM theory, PM practice)</li>
    <li><strong>2‑Minute Rule ⚡:</strong> Jo 2 min me ho sakta → abhi karo</li>
    <li><strong>Batched Tasks 📦:</strong> Similar tasks ek saath (emails, notes)</li>
</ul>
<p><strong>Example Day Plan (Board Prep):</strong></p>
<ul>
    <li>6:30–7:00: Walk + light stretch</li>
    <li>7:15–8:15: Maths numericals (Pomodoro x2)</li>
    <li>8:15–8:30: Breakfast</li>
    <li>9:00–10:00: Science theory + highlight</li>
    <li>10:10–11:10: English grammar practice</li>
    <li>4:00–4:30: Revise summaries</li>
    <li>9:30: Phone off, lights dim, sleep routine</li>
</ul>

<h4>📝 Quick Revision (One‑Pager Cheats)</h4>
<ul>
    <li><strong>Stress Types: ACE =</strong> Acute, Chronic, Episodic</li>
    <li><strong>ABC of Stress:</strong> Awareness–Balance–Control</li>
    <li><strong>SMART:</strong> Specific, Measurable, Achievable, Relevant, Time‑bound</li>
    <li><strong>Time Tools:</strong> Pomodoro, Eisenhower Box, Time Blocking, 2‑Minute Rule</li>
    <li><strong>Independent Skills:</strong> Motivation, Discipline, Decision, Problem‑solving, Time, Accountability</li>
    <li><strong>Self‑Awareness:</strong> Journal + Feedback + Weekly Review</li>
</ul>

'''

    else:
        # Generic placeholder for units without content yet
        context['content_html'] = f"""<h3>Content coming soon</h3>
<p>Unit {unit} for Class {g} ({part}) is not yet available. Check back later.</p>
"""

    return render(request, 'unit_detail.html', context)


def unit_slug_detail(request, grade, part, slug):
    """Render unit pages identified by a slug (used for Part B friendly URLs) - requires login.

    Looks for a template at `units/class{grade}/{part}/{slug}.html` and
    renders it. Falls back to a simple 'coming soon' page if template
    does not exist.
    """
    if 'student_id' not in request.session:
        messages.warning(request, 'Please login to access units.')
        return redirect('website:student_login')
    
    try:
        student = Student.objects.get(id=request.session['student_id'])
    except Student.DoesNotExist:
        messages.error(request, 'Student not found.')
        return redirect('website:student_login')
    
    try:
        g = int(grade)
    except (TypeError, ValueError):
        g = grade

    template_path = f'units/class{g}/{part}/{slug}.html'
    context = {'grade': g, 'part': part, 'slug': slug, 'student': student, 'is_locked': False}
    try:
        get_template(template_path)
        return render(request, template_path, context)
    except TemplateDoesNotExist:
        context['title'] = f'Class {g} — {part} — {slug}'
        context['content_html'] = f"""<h3>Content coming soon</h3>
<p>The page for <strong>{slug}</strong> (Class {g}, {part}) is not yet available.</p>
"""
        return render(request, 'unit_detail.html', context)

def student_signup(request):
    """Student registration view."""
    if request.method == 'POST':
        form = StudentSignupForm(request.POST)
        if form.is_valid():
            student = form.save()
            messages.success(request, 'Registration successful! Please login.')
            return redirect('website:student_login')
    else:
        form = StudentSignupForm()
    return render(request, 'registration/signup.html', {'form': form})


def student_login(request):
    """Student login view."""
    if request.method == 'POST':
        form = StudentLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            try:
                student = Student.objects.get(email=email)
                if student.check_password(password):
                    # Update last login
                    student.last_login = timezone.now()
                    student.save()
                    # Store student ID in session
                    request.session['student_id'] = student.id
                    request.session['student_name'] = student.name
                    messages.success(request, f'Welcome back, {student.name}!')
                    return redirect('website:home')
                else:
                    messages.error(request, 'Invalid password.')
            except Student.DoesNotExist:
                messages.error(request, 'Email not found. Please sign up first.')
    else:
        form = StudentLoginForm()
    return render(request, 'registration/login.html', {'form': form})


def student_logout(request):
    """Student logout view."""
    if 'student_id' in request.session:
        del request.session['student_id']
        del request.session['student_name']
    messages.success(request, 'You have been logged out.')
    return redirect('website:home')
